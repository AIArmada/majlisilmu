<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('languageables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('language_id')->index();
            $table->uuidMorphs('languageable');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('languageables');
    }
};
